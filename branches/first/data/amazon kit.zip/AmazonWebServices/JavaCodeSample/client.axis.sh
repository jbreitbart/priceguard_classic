#! /bin/zsh -f
java org.apache.axis.wsdl.WSDL2Java -v -p com.amazon.soap.axis AmazonWebServices.wsdl